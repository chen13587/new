#!/usr/bin/env python3.6

print(__file__)